from itertools import cycle
from typing import Optional, Union

import numpy as np
from torch.utils.data import DataLoader

from spVIPESmulti.data import AnnDataManager
from spVIPESmulti.dataloaders._ann_dataloader import AnnDataLoader


class ConcatDataLoader(DataLoader):
    """DataLoader that supports a list of list of indices to load.

    Parameters
    ----------
    adata_manager
        :class:`~scvi.data.AnnDataManager` object that has been created via ``setup_anndata``.
    indices_list
        List where each element is a list of indices in the adata to load
    shuffle
        Whether the data should be shuffled
    use_labels
        Whether to use labels for sampling
    batch_size
        minibatch size to load each iteration
    data_and_attributes
        Dictionary with keys representing keys in data registry (``adata_manager.data_registry``)
        and value equal to desired numpy loading type (later made into torch tensor).
        If ``None``, defaults to all registered data.
    data_loader_kwargs
        Keyword arguments for :class:`~torch.utils.data.DataLoader`
    """

    def __init__(
        self,
        adata_manager: AnnDataManager,
        indices_list: list[list[int]],
        shuffle: bool = True,
        use_labels: bool = False,
        batch_size: int = 128,
        data_and_attributes: Optional[dict] = None,
        drop_last: Union[bool, int] = False,
        **data_loader_kwargs,
    ):
        self.adata_manager = adata_manager
        self.groups_obs_indices = adata_manager.adata.uns["groups_obs_indices"]
        self.dataloader_kwargs = data_loader_kwargs
        self.data_and_attributes = data_and_attributes
        self._batch_size = batch_size
        self._drop_last = drop_last
        self._shuffle = shuffle

        self.dataloaders = []
        for gi, indices in enumerate(indices_list):
            # If a group is too small to fill a single batch under drop_last=True
            # the resulting dataloader has length 0 — and `cycle()` over an empty
            # iterator yields nothing, so `zip(*iter_list)` would silently end
            # the epoch with zero training batches. Disable drop_last for any
            # such group so it cycles its (smaller) batches instead.
            n_indices = len(indices)
            if drop_last and n_indices < batch_size:
                group_drop_last: Union[bool, int] = False
            else:
                group_drop_last = drop_last
            self.dataloaders.append(
                AnnDataLoader(
                    adata_manager,
                    indices=indices,
                    shuffle=shuffle,
                    use_labels=use_labels,
                    batch_size=batch_size,
                    data_and_attributes=data_and_attributes,
                    drop_last=group_drop_last,
                    **self.dataloader_kwargs,
                )
            )

        if not self.dataloaders:
            raise ValueError(
                "ConcatDataLoader requires at least one group (indices_list is empty)."
            )
        lens = [len(dl) for dl in self.dataloaders]
        empty = [gi for gi, n in enumerate(lens) if n == 0]
        if empty:
            raise ValueError(
                f"ConcatDataLoader: groups {empty} have zero batches "
                f"(group sizes {[len(idx) for idx in indices_list]}, batch_size={batch_size}, "
                f"drop_last={drop_last}). Lower batch_size or supply more cells."
            )
        self.largest_dl = self.dataloaders[np.argmax(lens)]
        super().__init__(self.largest_dl, **data_loader_kwargs)

    def __len__(self):
        return len(self.largest_dl)

    def __iter__(self):
        import torch
        import numpy as np
        iter_list = [cycle(dl) if dl != self.largest_dl else dl for dl in self.dataloaders]
        for batches in zip(*iter_list):
            # batches is a tuple of dicts, one per group
            merged = {}
            for d in batches:
                for k, v in d.items():
                    if k not in merged:
                        merged[k] = []
                    merged[k].append(v)
            # Now stack/concat along batch dimension
            for k in merged:
                if isinstance(merged[k][0], torch.Tensor):
                    merged[k] = torch.cat(merged[k], dim=0)
                elif isinstance(merged[k][0], np.ndarray):
                    merged[k] = np.concatenate(merged[k], axis=0)
                else:
                    # fallback: keep as list
                    merged[k] = sum(merged[k], []) if isinstance(merged[k][0], list) else merged[k]
            yield merged
