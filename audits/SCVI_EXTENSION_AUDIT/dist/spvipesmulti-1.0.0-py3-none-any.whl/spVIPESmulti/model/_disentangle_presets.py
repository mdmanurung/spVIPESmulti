"""Named presets for the disentanglement objective.

The disentanglement losses are inspired by CellDISECT's cross-covariate
decoupling MLPs and Multi-ContrastiveVAE. They are not the original
"Mutual Information Gap" metric (Chen et al. 2018), which is a post-hoc
disentanglement *metric*. What we implement here is a mix of:

  * adversarial domain-invariance losses via gradient reversal (DANN-style),
  * supervised classification losses acting as variational MI lower bounds,
  * an optional prototype InfoNCE on the shared latent.

Each preset is a dict of weight overrides. Users select a preset via
``disentangle_preset=...`` on the :class:`~spVIPESmulti.model.spVIPESmulti` model, and
may further override individual weights by passing them explicitly. ``None``
on a per-weight kwarg means "use the preset's value"; a numeric value
(including ``0.0``) overrides the preset for that component.

The package currently includes group/label components, optional batch and donor
covariate components, and optional prototype InfoNCE. The F4 bio presets are
retained for reproducibility, but current audit evidence does not support
promoting them as generally useful defaults.
"""

DISENTANGLE_PRESETS: dict[str, dict[str, float]] = {
    "off": {
        "disentangle_group_shared_weight": 0.0,
        "disentangle_label_shared_weight": 0.0,
        "disentangle_group_private_weight": 0.0,
        "disentangle_label_private_weight": 0.0,
        "disentangle_batch_shared_weight": 0.0,
        "disentangle_donor_shared_weight": 0.0,
        "disentangle_donor_private_weight": 0.0,
        "contrastive_weight": 0.0,
        "orthogonality_weight": 0.0,
    },
    "full": {
        # All 4 classifiers + contrastive at sensible defaults.
        "disentangle_group_shared_weight": 1.0,
        "disentangle_label_shared_weight": 1.0,
        "disentangle_group_private_weight": 1.0,
        "disentangle_label_private_weight": 1.0,
        "disentangle_batch_shared_weight": 0.0,
        "disentangle_donor_shared_weight": 0.0,
        "disentangle_donor_private_weight": 0.0,
        "contrastive_weight": 0.5,
        "orthogonality_weight": 0.0,
    },
    "shared_only": {
        # Only the z_shared decoupling losses.
        "disentangle_group_shared_weight": 1.0,
        "disentangle_label_shared_weight": 1.0,
        "disentangle_group_private_weight": 0.0,
        "disentangle_label_private_weight": 0.0,
        "disentangle_batch_shared_weight": 0.0,
        "disentangle_donor_shared_weight": 0.0,
        "disentangle_donor_private_weight": 0.0,
        "contrastive_weight": 0.5,
        "orthogonality_weight": 0.0,
    },
    "private_only": {
        # Only the z_private decoupling losses.
        "disentangle_group_shared_weight": 0.0,
        "disentangle_label_shared_weight": 0.0,
        "disentangle_group_private_weight": 1.0,
        "disentangle_label_private_weight": 1.0,
        "disentangle_batch_shared_weight": 0.0,
        "disentangle_donor_shared_weight": 0.0,
        "disentangle_donor_private_weight": 0.0,
        "contrastive_weight": 0.0,
        "orthogonality_weight": 0.0,
    },
    "adversarial_only": {
        # Only the GRL-based components.
        "disentangle_group_shared_weight": 1.0,
        "disentangle_label_shared_weight": 0.0,
        "disentangle_group_private_weight": 0.0,
        "disentangle_label_private_weight": 1.0,
        "disentangle_batch_shared_weight": 0.0,
        "disentangle_donor_shared_weight": 0.0,
        "disentangle_donor_private_weight": 0.0,
        "contrastive_weight": 0.0,
        "orthogonality_weight": 0.0,
    },
    "supervised_only": {
        # Only the non-GRL components (label-shared, group-private, contrastive).
        "disentangle_group_shared_weight": 0.0,
        "disentangle_label_shared_weight": 1.0,
        "disentangle_group_private_weight": 1.0,
        "disentangle_label_private_weight": 0.0,
        "disentangle_batch_shared_weight": 0.0,
        "disentangle_donor_shared_weight": 0.0,
        "disentangle_donor_private_weight": 0.0,
        "contrastive_weight": 0.5,
        "orthogonality_weight": 0.0,
    },
    "no_contrastive": {
        # Full disentanglement but with contrastive disabled.
        "disentangle_group_shared_weight": 1.0,
        "disentangle_label_shared_weight": 1.0,
        "disentangle_group_private_weight": 1.0,
        "disentangle_label_private_weight": 1.0,
        "disentangle_batch_shared_weight": 0.0,
        "disentangle_donor_shared_weight": 0.0,
        "disentangle_donor_private_weight": 0.0,
        "contrastive_weight": 0.0,
        "orthogonality_weight": 0.0,
    },
    "minimal_safe_bio": {
        "disentangle_group_shared_weight": 0.0,
        "disentangle_label_shared_weight": 0.0,
        "disentangle_group_private_weight": 0.0,
        "disentangle_label_private_weight": 0.0,
        "disentangle_batch_shared_weight": 0.0,
        "disentangle_donor_shared_weight": 0.0,
        "disentangle_donor_private_weight": 0.5,
        "contrastive_weight": 0.0,
        "orthogonality_weight": 0.0,
    },
    "full_bio": {
        "disentangle_group_shared_weight": 1.0,
        "disentangle_label_shared_weight": 1.0,
        "disentangle_group_private_weight": 1.0,
        "disentangle_label_private_weight": 1.0,
        "disentangle_batch_shared_weight": 0.5,
        "disentangle_donor_shared_weight": 0.5,
        "disentangle_donor_private_weight": 0.5,
        "contrastive_weight": 0.5,
        "orthogonality_weight": 0.0,
    },
}

_REQUIRED_PRESET_KEYS = frozenset({
    "disentangle_group_shared_weight",
    "disentangle_label_shared_weight",
    "disentangle_group_private_weight",
    "disentangle_label_private_weight",
    "disentangle_batch_shared_weight",
    "disentangle_donor_shared_weight",
    "disentangle_donor_private_weight",
    "contrastive_weight",
    "orthogonality_weight",
})

for _preset_name, _preset_vals in DISENTANGLE_PRESETS.items():
    _missing = _REQUIRED_PRESET_KEYS - _preset_vals.keys()
    if _missing:
        raise RuntimeError(
            f"DISENTANGLE_PRESETS['{_preset_name}'] is missing required keys: {_missing}"
        )
