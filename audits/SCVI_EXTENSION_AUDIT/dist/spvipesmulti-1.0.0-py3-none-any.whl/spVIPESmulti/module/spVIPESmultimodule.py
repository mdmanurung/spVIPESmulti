"""Main module."""
from typing import Literal, Optional

import numpy as np
import torch
import torch.nn.functional as F
import zuko.flows
from scvi import REGISTRY_KEYS
from scvi.distributions import NegativeBinomialMixture
from scvi.module.base import BaseModuleClass, LossOutput, auto_move_data
from torch.distributions import Normal
from torch.distributions import kl_divergence as kl

from scvi.nn import FCLayers
from spVIPESmulti.nn.networks import Encoder, LinearDecoderSPVIPE
from spVIPESmulti.module.utils import gradient_reversal


def _to_float_tensor(x: torch.Tensor | np.ndarray, device: torch.device) -> torch.Tensor:
    if isinstance(x, torch.Tensor):
        return x.to(device=device, dtype=torch.float32)
    return torch.as_tensor(x, device=device, dtype=torch.float32)


def _to_1d_tensor(x: torch.Tensor | np.ndarray, device: torch.device) -> torch.Tensor:
    if isinstance(x, torch.Tensor):
        return x.to(device=device).reshape(-1)
    return torch.as_tensor(x, device=device).reshape(-1)


def _within_stratum_corr_norm(
    z_shared: torch.Tensor | np.ndarray,
    z_private: torch.Tensor | np.ndarray,
    strata_ids: torch.Tensor | np.ndarray,
    min_cells: int = 16,
) -> tuple[float, float, int]:
    """Compute conditional shared-private leakage score within strata.

    The score is the mean squared aligned cross-correlation inside each
    stratum. Aligned means the first ``min(d_shared, d_private)`` dimensions
    are compared pairwise.
    """
    device = z_shared.device if isinstance(z_shared, torch.Tensor) else torch.device("cpu")
    zs = _to_float_tensor(z_shared, device)
    zp = _to_float_tensor(z_private, device)
    strata = _to_1d_tensor(strata_ids, device)

    n_align = min(zs.shape[1], zp.shape[1])
    if n_align == 0:
        return 0.0, 0.0, 0

    scores: list[float] = []
    excluded = 0

    for sid in torch.unique(strata):
        mask = strata == sid
        n = int(mask.sum().item())
        if n < min_cells:
            excluded += 1
            continue

        zs_s = zs[mask]
        zp_s = zp[mask]
        zs_s = zs_s - zs_s.mean(dim=0, keepdim=True)
        zp_s = zp_s - zp_s.mean(dim=0, keepdim=True)

        zs_std = zs_s.std(dim=0, unbiased=False).clamp_min(1e-8)
        zp_std = zp_s.std(dim=0, unbiased=False).clamp_min(1e-8)
        zs_z = zs_s / zs_std
        zp_z = zp_s / zp_std

        corr = (zs_z.T @ zp_z) / max(1, n - 1)
        diag_corr = torch.diagonal(corr[:n_align, :n_align])
        score = float(torch.mean(diag_corr.pow(2)).item())
        scores.append(score)

    if not scores:
        return 0.0, 0.0, excluded

    return float(np.mean(scores)), float(np.max(scores)), excluded


def _within_stratum_corr_norm_multimodal(
    z_shared: torch.Tensor | np.ndarray,
    z_private_by_modality: dict[int | str, torch.Tensor | np.ndarray],
    strata_ids: torch.Tensor | np.ndarray,
    min_cells: int = 16,
) -> tuple[float, float, int]:
    """Average the within-stratum leakage score across modalities."""
    means: list[float] = []
    worsts: list[float] = []
    excluded_counts: list[int] = []
    for z_private in z_private_by_modality.values():
        m, w, excluded = _within_stratum_corr_norm(
            z_shared,
            z_private,
            strata_ids,
            min_cells=min_cells,
        )
        means.append(m)
        worsts.append(w)
        excluded_counts.append(excluded)

    if not means:
        return 0.0, 0.0, 0
    return float(np.mean(means)), float(np.max(worsts)), int(np.max(excluded_counts))


def _orthogonality_corr_loss(
    z_shared: torch.Tensor | np.ndarray,
    z_private: torch.Tensor | np.ndarray,
    strata_ids: torch.Tensor | np.ndarray,
    min_cells: int = 16,
    eps: float = 1e-4,
) -> torch.Tensor:
    """Differentiable F3 shared-private correlation penalty within strata.

    This mirrors the F1 aligned-dimension leakage score but keeps the whole
    computation in torch so gradients can flow into both latent blocks.
    """
    device = z_shared.device if isinstance(z_shared, torch.Tensor) else torch.device("cpu")
    zs = _to_float_tensor(z_shared, device)
    zp = _to_float_tensor(z_private, device)
    strata = _to_1d_tensor(strata_ids, device)

    n_align = min(zs.shape[1], zp.shape[1])
    if n_align == 0 or zs.shape[0] == 0:
        return (zs.sum() + zp.sum()) * 0.0

    zs = zs[:, :n_align]
    zp = zp[:, :n_align]
    scores: list[torch.Tensor] = []
    valid: list[torch.Tensor] = []

    for sid in torch.unique(strata):
        mask = strata == sid
        mask_f = mask.to(dtype=zs.dtype).unsqueeze(1)
        n = mask_f.sum().clamp_min(1.0)

        zs_mean = (zs * mask_f).sum(dim=0, keepdim=True) / n
        zp_mean = (zp * mask_f).sum(dim=0, keepdim=True) / n
        zs_centered = (zs - zs_mean) * mask_f
        zp_centered = (zp - zp_mean) * mask_f

        zs_scale = torch.sqrt(zs_centered.pow(2).sum(dim=0, keepdim=True) / n + eps)
        zp_scale = torch.sqrt(zp_centered.pow(2).sum(dim=0, keepdim=True) / n + eps)
        corr = ((zs_centered / zs_scale) * (zp_centered / zp_scale)).sum(dim=0) / n
        corr = corr.clamp(min=-1.0, max=1.0)
        scores.append(corr.pow(2).mean())
        valid.append((mask_f.sum() >= min_cells).to(dtype=zs.dtype))

    if not scores:
        return (zs.sum() + zp.sum()) * 0.0

    scores_t = torch.stack(scores)
    valid_t = torch.stack(valid)
    return (scores_t * valid_t).sum() / valid_t.sum().clamp_min(1.0)


def _orthogonality_corr_loss_multimodal(
    z_shared: torch.Tensor | np.ndarray,
    z_private_by_modality: dict[int | str, torch.Tensor | np.ndarray],
    strata_ids: torch.Tensor | np.ndarray,
    min_cells: int = 16,
) -> torch.Tensor:
    """Average differentiable F3 loss across modality-private latents."""
    device = z_shared.device if isinstance(z_shared, torch.Tensor) else torch.device("cpu")
    losses = [
        _orthogonality_corr_loss(z_shared, z_private, strata_ids, min_cells=min_cells)
        for z_private in z_private_by_modality.values()
    ]
    if not losses:
        zs = _to_float_tensor(z_shared, device)
        return zs.sum() * 0.0
    return torch.stack(losses).mean()


def _orthogonality_strata_ids(
    tensors: dict,
    groupby_keys: tuple[str, ...],
    device: torch.device,
    n_obs: int,
) -> torch.Tensor | None:
    """Build stratum ids from registered tensors for F1 metrics and F3 loss."""
    if len(groupby_keys) == 0:
        return torch.zeros(n_obs, device=device, dtype=torch.long)

    strata_parts = [
        _to_1d_tensor(tensors[key], device)
        for key in groupby_keys
        if key in tensors
    ]
    if not strata_parts:
        return None
    if len(strata_parts) == 1:
        return strata_parts[0]

    stacked = torch.stack(strata_parts, dim=1)
    _, strata_ids = torch.unique(stacked, dim=0, return_inverse=True)
    return strata_ids


class spVIPESmultimodule(BaseModuleClass):
    """
    PyTorch implementation of spVIPESmulti variational autoencoder module.

    This module implements the core variational autoencoder with Product of Experts (PoE)
    for shared-private latent space learning. It extends scVI's underlying VAE architecture
    with multi-group integration capabilities and support for different PoE strategies.

    Parameters
    ----------
    groups_lengths : list of int
        List containing the number of features (genes) for each group/dataset.
    groups_obs_names : list
        List of observation names for each group.
    groups_var_names : list
        List of variable (gene) names for each group.
    groups_obs_indices : list
        List of observation indices for each group.
    groups_var_indices : list
        List of variable indices for each group.
    use_labels : bool, default=False
        Whether to use cell type labels for supervised PoE alignment.
    n_labels : int, optional
        Number of unique cell type labels when using supervised alignment.
    n_batch : int, default=0
        Number of batches. If 0, no batch correction is performed.
    n_hidden : int, default=128
        Number of nodes per hidden layer in encoder and decoder networks.
    n_dimensions_shared : int, default=25
        Dimensionality of the shared latent space capturing common features.
    n_dimensions_private : int, default=10
        Dimensionality of private latent spaces capturing group-specific features.
    dropout_rate : float, default=0.1
        Dropout rate for neural networks to prevent overfitting.
    use_batch_norm : bool, default=True
        Whether to use batch normalization in neural networks.
    use_layer_norm : bool, default=False
        Whether to use layer normalization in neural networks.
    log_variational_inference : bool, default=True
        Whether to log-transform data before encoding for numerical stability.
    log_variational_generative : bool, default=True
        Whether to log-transform data before decoding for numerical stability.
    dispersion : {"gene", "gene-batch", "gene-cell"}, default="gene"
        Level at which to model the dispersion parameter in the negative binomial distribution.
    encoder_activation : {"silu", "relu", "leakyrelu"}, default="silu"
        Activation function used in all encoder hidden layers.
    use_low_rank_mixer : bool, default=False
        If ``True``, use a lightweight rank-``low_rank_mixer_rank`` bottleneck
        in the decoder mixer instead of the full FCLayers chain.
    low_rank_mixer_rank : int, default=4
        Bottleneck rank when ``use_low_rank_mixer=True``.
    label_class_weights : torch.Tensor, optional
        1-D tensor of length ``n_labels`` with per-class weights for the
        label cross-entropy losses (Components 2 and 4). Passed directly to
        ``F.cross_entropy(weight=...)``. If ``None`` (default), uniform
        weights are used. Typically set to inverse class frequencies so
        minority cell types receive proportionally larger gradient signals.

    Notes
    -----
    This module is based on the scVI framework and implements the variational inference
    described in the spVIPESmulti paper. The Product of Experts mechanism allows for flexible
    integration of multiple single-cell datasets with different feature sets.
    """

    def __init__(
        self,
        groups_lengths,
        groups_obs_names,
        groups_var_names,
        groups_obs_indices,
        groups_var_indices,
        use_labels: bool = False,
        n_labels: Optional[int] = None,
        use_condition: bool = False,
        n_conditions: Optional[int] = None,
        use_donor: bool = False,
        n_donors: Optional[int] = None,
        use_batch_covariate: bool = False,
        n_batch: int = 0,
        n_hidden: int = 128,
        n_dimensions_shared: int = 25,
        n_dimensions_private: int = 10,
        dropout_rate: float = 0.1,
        use_batch_norm: bool = True,
        use_layer_norm: bool = False,
        log_variational_inference: bool = True,
        log_variational_generative: bool = True,
        dispersion: Literal["gene", "gene-batch", "gene-cell"] = "gene",
        # Multimodal parameters
        groups_modality_lengths: Optional[dict] = None,
        groups_modality_var_indices: Optional[dict] = None,
        modality_likelihoods: Optional[dict[str, str]] = None,
        modality_names: Optional[list[str]] = None,
        groups_modality_masks: Optional[dict] = None,
        modality_loss_weights: Optional[dict[str, float]] = None,
        use_jeffreys_integ: bool = False,
        jeffreys_integ_weight: float = 1.0,
        # Normalizing flow prior parameters
        use_nf_prior: bool = False,
        nf_type: Literal["NSF", "MAF"] = "NSF",
        nf_transforms: int = 3,
        nf_bins: int = 8,
        nf_target: Literal["shared", "private", "both"] = "shared",
        # Disentanglement objective parameters (CellDISECT / Multi-ContrastiveVAE)
        disentangle_group_shared_weight: float = 0.0,
        disentangle_label_shared_weight: float = 0.0,
        disentangle_group_private_weight: float = 0.0,
        disentangle_label_private_weight: float = 0.0,
        disentangle_batch_shared_weight: float = 0.0,
        disentangle_donor_shared_weight: float = 0.0,
        disentangle_donor_private_weight: float = 0.0,
        contrastive_weight: float = 0.0,
        orthogonality_weight: float = 0.0,
        contrastive_temperature: float = 0.1,
        disentangle_warmup: bool = True,
        group_loss_weights: Optional[list[float]] = None,
        strict_likelihood_support: bool = False,
        validate_observations: bool = False,
        encoder_activation: str = "silu",
        use_low_rank_mixer: bool = False,
        low_rank_mixer_rank: int = 4,
        label_class_weights: Optional[torch.Tensor] = None,
        compute_orthogonality_metric: bool = False,
        orthogonality_groupby_keys: tuple[str, ...] = ("sample",),
        orthogonality_min_cells_per_stratum: int = 16,
    ):
        """
        Initialize the spVIPESmulti variational autoencoder module.

        This method sets up the neural network components including encoders and decoders
        for each group, and configures the Product of Experts mechanism based on the
        provided parameters. The module extends scVI's VAE architecture for multi-group
        integration with shared-private latent spaces.

        Notes
        -----
        The initialization automatically configures the appropriate PoE strategy based on
        the provided inputs (use_labels). The module creates
        separate encoders and decoders for each group while sharing the latent space
        structure for integration.

        For multimodal data, provide ``groups_modality_lengths``, ``groups_modality_var_indices``,
        ``modality_likelihoods``, and ``modality_names``. Each (group, modality) pair gets
        its own encoder and decoder, with a two-level PoE: intra-group across modalities,
        then inter-group.
        """
        super().__init__()
        self.n_dimensions_shared = n_dimensions_shared
        self.n_dimensions_private = n_dimensions_private
        self.n_batch = n_batch
        self.input_dims = groups_lengths
        self.groups_barcodes = groups_obs_names
        self.groups_genes = groups_var_names
        self.groups_obs_indices = groups_obs_indices
        self.groups_var_indices = groups_var_indices
        self.use_batch_norm = use_batch_norm
        self.use_layer_norm = use_layer_norm
        self.label_per_batch = []
        self.dispersion = dispersion
        self.log_variational_inference = log_variational_inference
        self.log_variational_generative = log_variational_generative
        self.strict_likelihood_support = strict_likelihood_support
        self.validate_observations = validate_observations
        self.encoder_activation = encoder_activation
        self.use_low_rank_mixer = use_low_rank_mixer
        self.low_rank_mixer_rank = low_rank_mixer_rank
        self.compute_orthogonality_metric = compute_orthogonality_metric
        self.orthogonality_groupby_keys = orthogonality_groupby_keys
        self.orthogonality_min_cells_per_stratum = orthogonality_min_cells_per_stratum
        self.register_buffer("label_class_weights", label_class_weights)

        # Multimodal configuration
        self.is_multimodal = groups_modality_lengths is not None
        self.groups_modality_lengths = groups_modality_lengths
        self.groups_modality_var_indices = groups_modality_var_indices
        self.modality_likelihoods = modality_likelihoods or {}
        self.modality_names = modality_names or []
        self.groups_modality_masks = groups_modality_masks or {}
        self.modality_loss_weights = modality_loss_weights or {}
        self.use_jeffreys_integ = use_jeffreys_integ
        self.jeffreys_integ_weight = jeffreys_integ_weight
        # Track which modalities each group has
        if self.is_multimodal:
            self.group_modalities = {g: list(mod_dict.keys()) for g, mod_dict in groups_modality_lengths.items()}
        else:
            self.group_modalities = None

        cat_list = [n_batch] if n_batch > 0 else None

        if self.is_multimodal:
            # Multimodal mode: per-(group, modality) encoders and decoders
            self.px_r = torch.nn.ParameterDict()
            self.log_scale_gaussian = torch.nn.ParameterDict()
            self.encoders = {}
            self.decoders = {}

            for group, mod_dict in groups_modality_lengths.items():
                for modality, n_features in mod_dict.items():
                    key = f"{group}_{modality}"
                    self.px_r[key] = torch.nn.Parameter(torch.randn(n_features))
                    if (modality_likelihoods or {}).get(modality, "nb") == "gaussian":
                        self.log_scale_gaussian[key] = torch.nn.Parameter(torch.zeros(n_features))

                    self.encoders[(group, modality)] = {
                        "shared": Encoder(
                            n_features, n_dimensions_shared,
                            hidden=n_hidden, dropout=dropout_rate,
                            n_cat_list=cat_list, groups=group,
                            encoder_activation=encoder_activation,
                        ),
                        "private": Encoder(
                            n_features, n_dimensions_private,
                            hidden=n_hidden, dropout=dropout_rate,
                            n_cat_list=cat_list, groups=group,
                            encoder_activation=encoder_activation,
                        ),
                    }
                    self.decoders[(group, modality)] = LinearDecoderSPVIPE(
                        n_dimensions_private, n_dimensions_shared, n_features,
                        n_cat_list=cat_list, use_batch_norm=True,
                        use_layer_norm=False, bias=False,
                        use_low_rank_mixer=use_low_rank_mixer,
                        low_rank_mixer_rank=low_rank_mixer_rank,
                    )

            # Register sub-modules
            for (group, modality), enc_dict in self.encoders.items():
                self.add_module(f"encoder_{group}_{modality}_shared", enc_dict["shared"])
                self.add_module(f"encoder_{group}_{modality}_private", enc_dict["private"])
            for (group, modality), dec in self.decoders.items():
                self.add_module(f"decoder_{group}_{modality}", dec)
        else:
            # Single-modality mode (backward compatible)
            self.px_r = torch.nn.ParameterList(
                [torch.nn.Parameter(torch.randn(length)) for length in groups_lengths.values()]
            )
            self.encoders = {
                groups: {
                    "shared": Encoder(
                        x_dim, n_dimensions_shared,
                        hidden=n_hidden, dropout=dropout_rate,
                        n_cat_list=cat_list, groups=groups,
                        encoder_activation=encoder_activation,
                    ),
                    "private": Encoder(
                        x_dim, n_dimensions_private,
                        hidden=n_hidden, dropout=dropout_rate,
                        n_cat_list=cat_list, groups=groups,
                        encoder_activation=encoder_activation,
                    ),
                }
                for groups, x_dim in self.input_dims.items()
            }
            self.decoders = {
                groups: LinearDecoderSPVIPE(
                    n_dimensions_private, n_dimensions_shared, x_dim,
                    n_cat_list=cat_list, use_batch_norm=True,
                    use_layer_norm=False, bias=False,
                    use_low_rank_mixer=use_low_rank_mixer,
                    low_rank_mixer_rank=low_rank_mixer_rank,
                )
                for groups, x_dim in self.input_dims.items()
            }

            # Register sub-modules
            for (groups, values_encoder), (_, values_decoder) in zip(self.encoders.items(), self.decoders.items()):
                self.add_module(f"encoder_{groups}_shared", values_encoder["shared"])
                self.add_module(f"encoder_{groups}_private", values_encoder["private"])
                self.add_module(f"decoder_{groups}", values_decoder)

        self.use_labels = use_labels
        self.n_labels = n_labels
        self.use_condition = use_condition
        self.n_conditions = n_conditions
        self.use_donor = use_donor
        self.n_donors = n_donors
        self.use_batch_covariate = use_batch_covariate

        if use_labels and n_labels is None:
            raise ValueError(
                "n_labels must be provided when use_labels=True. "
                "Ensure label_key is passed to setup_anndata() before constructing the model."
            )
        if use_condition and n_conditions is None:
            raise ValueError(
                "n_conditions must be provided when use_condition=True. "
                "Ensure condition_key is passed to setup_anndata() before constructing the model."
            )
        if use_donor and n_donors is None:
            raise ValueError(
                "n_donors must be provided when use_donor=True. "
                "Ensure donor_key is passed to setup_anndata() before constructing the model."
            )

        # Normalizing flow prior
        self.use_nf_prior = use_nf_prior
        self.nf_target = nf_target
        if use_nf_prior:
            flow_cls = zuko.flows.NSF if nf_type == "NSF" else zuko.flows.MAF
            flow_kwargs = {"transforms": nf_transforms}
            if nf_type == "NSF":
                flow_kwargs["bins"] = nf_bins

            if nf_target in ("shared", "both"):
                self.flow_prior_shared = flow_cls(features=n_dimensions_shared, context=0, **flow_kwargs)
            if nf_target in ("private", "both"):
                self.flow_prior_private = flow_cls(features=n_dimensions_private, context=0, **flow_kwargs)

        # Disentanglement objective: 4 auxiliary classifiers (CellDISECT-style).
        # Note: this is NOT the MIG metric (Chen et al. 2018) — these are a mix
        # of adversarial domain-invariance losses (GRL) and supervised CE losses
        # acting as variational MI lower bounds. Group classifiers (q_group_*)
        # require only group identity (always known); label classifiers and
        # contrastive require use_labels=True.

        # Disentanglement is supported in multimodal mode (P8). Components
        # 1, 2, 5 (shared / contrastive) operate on the post-PoE shared latent
        # — modality-agnostic by construction. Components 3, 4 (private) loop
        # over per-modality private latents in `_compute_disentangle_losses`
        # when `self.is_multimodal` is True.

        _label_required = (
            ("disentangle_label_shared_weight", disentangle_label_shared_weight),
            ("disentangle_label_private_weight", disentangle_label_private_weight),
            ("contrastive_weight", contrastive_weight),
        )
        _violations = [name for name, w in _label_required if w > 0]
        if _violations and not use_labels:
            raise ValueError(
                f"The following disentanglement/contrastive weights require use_labels=True "
                f"(label-based PoE): {_violations}. Either provide a label_key "
                f"in setup_anndata() or set those weights to 0.0. Group classifiers "
                f"(q_group_shared, q_group_private) do not require labels and "
                f"remain enabled."
            )

        _donor_required = (
            ("disentangle_donor_shared_weight", disentangle_donor_shared_weight),
            ("disentangle_donor_private_weight", disentangle_donor_private_weight),
        )
        _donor_violations = [name for name, w in _donor_required if w > 0]
        if _donor_violations and not use_donor:
            raise ValueError(
                f"The following covariate disentanglement weights require donor_key "
                f"in setup_anndata(): {_donor_violations}. Either provide donor_key "
                f"or set those weights to 0.0."
            )

        if disentangle_batch_shared_weight > 0 and not use_batch_covariate:
            raise ValueError(
                "disentangle_batch_shared_weight requires batch_key in setup_anndata() "
                "with at least two batch categories. Either provide batch_key or set "
                "disentangle_batch_shared_weight=0.0."
            )
        if orthogonality_weight < 0:
            raise ValueError(
                f"orthogonality_weight must be >= 0, got {orthogonality_weight}."
            )

        n_groups = len(groups_lengths)
        self.disentangle_group_shared_weight = disentangle_group_shared_weight
        self.disentangle_label_shared_weight = disentangle_label_shared_weight
        self.disentangle_group_private_weight = disentangle_group_private_weight
        self.disentangle_label_private_weight = disentangle_label_private_weight
        self.disentangle_batch_shared_weight = disentangle_batch_shared_weight
        self.disentangle_donor_shared_weight = disentangle_donor_shared_weight
        self.disentangle_donor_private_weight = disentangle_donor_private_weight
        self.contrastive_weight = contrastive_weight
        self.orthogonality_weight = float(orthogonality_weight)
        self.contrastive_temperature = contrastive_temperature
        self.disentangle_warmup = disentangle_warmup
        if group_loss_weights is not None:
            s = sum(group_loss_weights)
            self.group_loss_weights: Optional[list[float]] = [w / s for w in group_loss_weights]
        else:
            self.group_loss_weights = None

        _clf_kwargs = dict(n_layers=2, n_hidden=64, dropout_rate=0.1, use_batch_norm=True)

        # Classifier 2: adversarial — erase group info from z_shared
        self.q_group_shared = (
            FCLayers(n_in=n_dimensions_shared, n_out=n_groups, **_clf_kwargs)
            if disentangle_group_shared_weight > 0 else None
        )
        # Classifier 1: supervised — preserve label info in z_shared
        self.q_label_shared = (
            FCLayers(n_in=n_dimensions_shared, n_out=n_labels, **_clf_kwargs)
            if disentangle_label_shared_weight > 0 and use_labels else None
        )
        # Classifier 3: supervised — preserve group info in z_private
        self.q_group_private = (
            FCLayers(n_in=n_dimensions_private, n_out=n_groups, **_clf_kwargs)
            if disentangle_group_private_weight > 0 else None
        )
        # Classifier 4: adversarial — erase label info from z_private
        self.q_label_private = (
            FCLayers(n_in=n_dimensions_private, n_out=n_labels, **_clf_kwargs)
            if disentangle_label_private_weight > 0 and use_labels else None
        )
        self.q_batch_shared = (
            FCLayers(n_in=n_dimensions_shared, n_out=n_batch, **_clf_kwargs)
            if disentangle_batch_shared_weight > 0 and use_batch_covariate else None
        )
        self.q_donor_shared = (
            FCLayers(n_in=n_dimensions_shared, n_out=n_donors, **_clf_kwargs)
            if disentangle_donor_shared_weight > 0 and use_donor else None
        )
        self.q_donor_private = (
            FCLayers(n_in=n_dimensions_private, n_out=n_donors, **_clf_kwargs)
            if disentangle_donor_private_weight > 0 and use_donor else None
        )

        # Optional prototype buffer for contrastive InfoNCE on z_shared.
        # Use register_buffer either way so the attribute is owned by nn.Module's
        # _buffers dict — assigning self.prototypes = None first crashes on
        # PyTorch >= 2.x because register_buffer refuses to re-bind a name
        # already present in __dict__.
        if contrastive_weight > 0 and use_labels:
            self.register_buffer("prototypes", torch.zeros(n_groups, n_labels, n_dimensions_shared))
            self.prototype_momentum = 0.99
        else:
            self.register_buffer("prototypes", None)

    def _covariate_grl_lambda(self, kl_weight: float = 1.0) -> float:
        """Effective GRL scale for F4 donor/batch adversarial heads."""
        if self.q_batch_shared is None and self.q_donor_shared is None:
            return 0.0
        return float(np.clip(float(kl_weight), 0.0, 1.0))


    def _cluster_based_poe(self, *args, **kwargs):
        raise NotImplementedError("Cluster-based PoE has been removed. Use label-based PoE (label_key=...) instead.")

    def _poe_n(self, shared_stats: dict):
        """Generic N-group Product of Experts.

        Combines shared statistics from N >= 2 groups using Gaussian PoE.
        Handles unequal batch sizes by padding with standard normal prior
        (loc=0, logvar=0 → var=1, precision=1).

        Parameters
        ----------
        shared_stats : dict[int, dict[str, Tensor]]
            Per-group encoder statistics with keys "logtheta_loc", "logtheta_logvar", "logtheta_scale".

        Returns
        -------
        dict[int, dict[str, Tensor]]
            Per-group PoE results with keys "logtheta_loc", "logtheta_logvar", "logtheta_scale".
        """
        group_keys = sorted(shared_stats.keys())
        n_groups = len(group_keys)
        if n_groups < 2:
            raise ValueError(f"PoE requires at least 2 groups, got {n_groups}")

        group_sizes = {g: shared_stats[g]["logtheta_logvar"].shape[0] for g in group_keys}
        max_batch_size = max(group_sizes.values())
        latent_dim = shared_stats[group_keys[0]]["logtheta_logvar"].shape[-1]
        device = shared_stats[group_keys[0]]["logtheta_logvar"].device

        # Pad each group to max_batch_size and stack
        # Padding: loc=0, logvar=0 → var=1, 1/var=1 (standard normal prior contribution)
        padded_locs = []
        padded_logvars = []
        for g in group_keys:
            loc = shared_stats[g]["logtheta_loc"]
            logvar = shared_stats[g]["logtheta_logvar"]
            g_size = group_sizes[g]
            if g_size < max_batch_size:
                pad_size = max_batch_size - g_size
                loc = torch.cat([loc, torch.zeros(pad_size, latent_dim, device=device)], dim=0)
                logvar = torch.cat([logvar, torch.zeros(pad_size, latent_dim, device=device)], dim=0)
            padded_locs.append(loc)
            padded_logvars.append(logvar)

        # Stack: shape (N, max_batch, latent_dim)
        stacked_mus = torch.stack(padded_locs, dim=0)
        stacked_logvars = torch.stack(padded_logvars, dim=0)

        # Compute joint PoE
        mus_joint, logvars_joint = self._product_of_experts(stacked_mus, stacked_logvars)

        # Slice back to each group's original size and build result
        result = {}
        for g in group_keys:
            g_size = group_sizes[g]
            g_mu = mus_joint[:g_size]
            g_logvar = logvars_joint[:g_size]
            g_scale = torch.sqrt(torch.exp(g_logvar))
            result[g] = {
                "logtheta_loc": g_mu,
                "logtheta_logvar": g_logvar,
                "logtheta_scale": g_scale,
            }

        return result


    def _split_tensors_by_group(self, tensors):
        """Split a merged minibatch dict into a list of per-group dicts.

        ``ConcatDataLoader`` concatenates all groups into a single dict keyed
        by the usual scvi-tools registry keys. The ``"groups"`` field contains
        integer category codes (0, 1, 2, …) identifying each cell's group.
        This helper splits that merged dict back into an ordered list of
        per-group dicts, sorted by ascending group code, so that
        ``per_group[i]`` always corresponds to group *i*.

        If *tensors* is already a list (e.g., a direct internal call), it is
        returned unchanged for backward compatibility.
        """
        if isinstance(tensors, list):
            return tensors

        # group_codes may be shape (N,) or (N, 1) — flatten to 1D for masking
        group_codes = tensors["groups"].reshape(-1)
        unique_groups = torch.unique(group_codes, sorted=True)

        per_group = []
        for g_code in unique_groups:
            mask = group_codes == g_code
            group_dict = {}
            for k, v in tensors.items():
                if isinstance(v, torch.Tensor):
                    group_dict[k] = v[mask]
                elif isinstance(v, np.ndarray):
                    group_dict[k] = v[mask.cpu().numpy()]
                else:
                    group_dict[k] = v
            per_group.append(group_dict)

        return per_group

    def _get_inference_input(self, tensors_by_group):
        per_group = self._split_tensors_by_group(tensors_by_group)
        x = {i: group[REGISTRY_KEYS.X_KEY] for i, group in enumerate(per_group)}
        batch_index = [group[REGISTRY_KEYS.BATCH_KEY] for group in per_group]
        groups = [group["groups"] for group in per_group]
        global_indices = [group.get("indices", None) for group in per_group]

        input_dict = {
            "x": x,
            "batch_index": batch_index,
            "groups": groups,
            "global_indices": global_indices,
        }

        if self.use_labels:
            if "labels" not in per_group[0]:
                raise ValueError("Labels are required when using label-based POE.")
            input_dict["labels"] = [group["labels"].flatten() for group in per_group]

        return input_dict

    def _get_generative_input(self, tensors_by_group, inference_outputs):
        per_group = self._split_tensors_by_group(tensors_by_group)
        private_stats = inference_outputs["private_stats"]
        shared_stats = inference_outputs["shared_stats"]
        poe_stats = inference_outputs["poe_stats"]
        library = inference_outputs["library"]
        groups = [g["groups"] for g in per_group]
        batch_index = [g[REGISTRY_KEYS.BATCH_KEY] for g in per_group]

        input_dict = {
            "private_stats": private_stats,
            "shared_stats": shared_stats,
            "poe_stats": poe_stats,
            "library": library,
            "groups": groups,
            "batch_index": batch_index,
        }

        # Pass through multimodal-specific data
        if "per_modality_private" in inference_outputs:
            input_dict["per_modality_private"] = inference_outputs["per_modality_private"]

        return input_dict

    @auto_move_data
    def inference(self, x, batch_index, groups, global_indices, **kwargs):
        """Runs the encoder model.

        In single-modality mode, runs per-group shared/private encoders then inter-group PoE.
        In multimodal mode, runs per-(group, modality) encoders, then intra-group PoE across
        modalities, then inter-group PoE.
        """
        if self.is_multimodal:
            return self._inference_multimodal(x, batch_index, groups, global_indices, **kwargs)

        # Single-modality mode (backward compatible)
        x = {
            i: xs[:, self.groups_var_indices[i]] for i, xs in x.items()
        }  # update each groups minibatch with its own gene indices

        if self.log_variational_inference:
            x = {i: torch.log(1 + xs) for i, xs in x.items()}  # logvariational

        library = {i: torch.log(xs.sum(1)).unsqueeze(1) for i, xs in x.items()}  # observed library size

        private_stats = {}
        shared_stats = {}

        for group, (item, batch) in enumerate(zip(x.values(), batch_index)):
            private_encoder = self.encoders[group]["private"]
            shared_encoder = self.encoders[group]["shared"]

            private_values = private_encoder(item, group, batch)
            shared_values = shared_encoder(item, group, batch)

            private_stats[group] = private_values
            shared_stats[group] = shared_values

        labels = None
        if self.use_labels:
            if "labels" in kwargs:
                labels = dict(enumerate(kwargs["labels"]))

        poe_stats = self._supervised_poe(shared_stats, labels)

        outputs = {
            "private_stats": private_stats,
            "shared_stats": shared_stats,
            "poe_stats": poe_stats,
            "library": library,
        }

        return outputs

    def _inference_multimodal(self, x, batch_index, groups, global_indices, **kwargs):
        """Multimodal inference with two-level PoE."""
        n_groups = len(x)

        # Step 1: Per-(group, modality) encoding
        per_modality_private = {}  # keyed by (group, modality)
        per_modality_shared = {}   # keyed by (group, modality)
        library = {}               # keyed by (group, modality)

        for group in range(n_groups):
            x_group = x[group]  # full concatenated features for this group
            batch = batch_index[group]

            for modality in self.group_modalities[group]:
                # Slice the group's data to this modality's features
                mod_var_indices = self.groups_modality_var_indices[group][modality]
                x_mod = x_group[:, mod_var_indices]

                # Modality-specific preprocessing
                likelihood = self.modality_likelihoods.get(modality, "nb")
                if likelihood == "nb" and self.log_variational_inference:
                    x_mod_enc = torch.log(1 + x_mod)
                else:
                    x_mod_enc = x_mod  # Gaussian: data already log-normalized

                lib = torch.log(x_mod.sum(1).clamp(min=1e-6)).unsqueeze(1)
                library[(group, modality)] = lib

                shared_enc = self.encoders[(group, modality)]["shared"]
                private_enc = self.encoders[(group, modality)]["private"]

                per_modality_shared[(group, modality)] = shared_enc(x_mod_enc, group, batch)
                per_modality_private[(group, modality)] = private_enc(x_mod_enc, group, batch)

        # Step 2: Intra-group PoE across modalities → per-group shared stats
        per_group_shared = {}
        for group in range(n_groups):
            modalities = self.group_modalities[group]
            if len(modalities) == 1:
                # Single modality in this group: use its shared stats directly
                mod = modalities[0]
                per_group_shared[group] = per_modality_shared[(group, mod)]
            else:
                # Multiple modalities: combine via PoE
                mod_shared = {}
                for idx, mod in enumerate(modalities):
                    stats = per_modality_shared[(group, mod)]
                    mod_shared[idx] = {
                        "logtheta_loc": stats["logtheta_loc"],
                        "logtheta_logvar": stats["logtheta_logvar"],
                        "logtheta_scale": stats["logtheta_scale"],
                    }
                intra_poe = self._poe_n(mod_shared)
                # Use index 0 result (all modalities have same batch size within a group)
                intra_mu = intra_poe[0]["logtheta_loc"]
                intra_logvar = intra_poe[0]["logtheta_logvar"]
                intra_scale = intra_poe[0]["logtheta_scale"]

                # Build full stats dict compatible with downstream
                qz = Normal(intra_mu, intra_scale.clamp(min=1e-6))
                log_z = qz.rsample()
                theta = F.softmax(log_z, -1)
                per_group_shared[group] = {
                    "logtheta_loc": intra_mu,
                    "logtheta_logvar": intra_logvar,
                    "logtheta_scale": intra_scale,
                    "log_z": log_z,
                    "theta": theta,
                    "qz": qz,
                }

        # Step 3: Inter-group PoE (label-based)
        labels = None
        if self.use_labels and "labels" in kwargs:
            labels = dict(enumerate(kwargs["labels"]))

        poe_stats = self._supervised_poe(per_group_shared, labels)

        # Build output: private_stats keyed by group (use first modality for backward compat)
        # For multimodal, we also include per-modality private stats
        private_stats = {}
        for group in range(n_groups):
            # Use first modality's private stats as the group-level private
            first_mod = self.group_modalities[group][0]
            private_stats[group] = per_modality_private[(group, first_mod)]

        outputs = {
            "private_stats": private_stats,
            "shared_stats": per_group_shared,
            "poe_stats": poe_stats,
            "library": library,
            "per_modality_private": per_modality_private,
            "per_modality_shared": per_modality_shared,
        }

        return outputs

    def _supervised_poe(
        self,
        shared_stats,
        labels: Optional[dict[int, torch.Tensor]],
    ):
        if self.use_labels and labels is not None:
            return self._label_based_poe(shared_stats, labels)
        # Unsupervised fallback: combine all groups via PoE without label alignment
        poe_result = self._poe_n(shared_stats)
        for g in sorted(poe_result.keys()):
            poe_result[g]["logtheta_qz"] = Normal(
                poe_result[g]["logtheta_loc"],
                poe_result[g]["logtheta_scale"].clamp(min=1e-6),
            )
            poe_result[g]["logtheta_log_z"] = poe_result[g]["logtheta_qz"].rsample()
            poe_result[g]["logtheta_theta"] = F.softmax(poe_result[g]["logtheta_log_z"], -1)
        return poe_result

    def _paired_poe(self, *args, **kwargs):
        raise NotImplementedError("Paired PoE has been removed. Use label-based PoE (label_key=...) instead.")

    def _jeffreys_divergence_loss(self, mu1, logvar1, mu2, logvar2):
        """Symmetric KL (Jeffreys divergence) between two batches of Gaussian posteriors.

        Aggregates each batch to a single representative Gaussian by averaging
        means and variances, then returns KL(p1‖p2) + KL(p2‖p1) summed over
        latent dimensions. This handles groups of unequal batch sizes.
        """
        var1 = logvar1.exp().mean(dim=0)
        var2 = logvar2.exp().mean(dim=0)
        agg_mu1 = mu1.mean(dim=0)
        agg_mu2 = mu2.mean(dim=0)
        rv1 = Normal(agg_mu1, var1.sqrt().clamp(min=1e-6))
        rv2 = Normal(agg_mu2, var2.sqrt().clamp(min=1e-6))
        return (kl(rv1, rv2) + kl(rv2, rv1)).sum()

    def _compute_jeffreys_integ_loss(self, inference_outputs, n_groups, extra_metrics):
        """Pairwise Jeffreys divergence across all group PoE posteriors.

        Following multigrate's alignment strategy (symmetric KL between groups),
        this loss pulls the shared latent distributions of all groups together
        without requiring matched cells or auxiliary networks.
        """
        poe_stats = inference_outputs["poe_stats"]
        device = poe_stats[0]["logtheta_loc"].device
        total = torch.zeros(1, device=device)

        for g1 in range(n_groups):
            for g2 in range(g1 + 1, n_groups):
                mu1 = poe_stats[g1]["logtheta_loc"]
                logvar1 = poe_stats[g1]["logtheta_logvar"]
                mu2 = poe_stats[g2]["logtheta_loc"]
                logvar2 = poe_stats[g2]["logtheta_logvar"]
                total = total + self._jeffreys_divergence_loss(mu1, logvar1, mu2, logvar2)

        n_pairs = max(1, n_groups * (n_groups - 1) // 2)
        loss = total / n_pairs
        extra_metrics["jeffreys_integ_loss"] = loss.detach().mean()
        return loss.squeeze(0)

    def _product_of_experts(self, mus, logvars):
        vars = torch.exp(logvars)
        mus_joint = torch.sum(mus / vars, dim=0)
        logvars_joint = torch.ones_like(mus_joint)
        logvars_joint += torch.sum(1.0 / vars, dim=0)
        logvars_joint = 1.0 / logvars_joint  # inverse
        mus_joint *= logvars_joint
        logvars_joint = torch.log(logvars_joint)
        return mus_joint, logvars_joint

    def _nf_kl(self, qz, z, target: str):
        """Compute KL divergence using normalizing flow prior via Monte Carlo.

        KL(q(z|x) || p_flow(z)) ≈ log q(z|x) - log p_flow(z)

        Parameters
        ----------
        qz : Normal
            Posterior distribution q(z|x).
        z : torch.Tensor
            Samples from q(z|x).
        target : str
            Which flow to use: "shared" or "private".

        Returns
        -------
        torch.Tensor
            KL divergence per sample, shape (batch_size,).
        """
        if target == "shared":
            flow_dist = self.flow_prior_shared()
        else:
            flow_dist = self.flow_prior_private()
        log_qz = qz.log_prob(z).sum(dim=-1)  # sum over latent dims
        log_pz = flow_dist.log_prob(z)  # flow gives scalar per sample
        return log_qz - log_pz

    def _label_based_poe(self, shared_stats: dict, label_group: dict):
        """Label-based PoE for N >= 2 groups.

        For each cell type label, combines shared encoder statistics from all groups
        that contain cells of that type using Product of Experts. Groups missing a label
        contribute an uninformative prior (loc=0, logvar=log(1)=0).
        """
        stat_keys = ["logtheta_loc", "logtheta_logvar", "logtheta_scale"]
        group_keys = sorted(shared_stats.keys())
        n_groups = len(group_keys)

        # Extract per-group stats and labels
        per_group_stats = {}
        per_group_labels = {}
        for g in group_keys:
            per_group_stats[g] = {k: shared_stats[g][k] for k in stat_keys if k in shared_stats[g]}
            per_group_labels[g] = label_group[g]

        # Collect all unique labels across all groups and determine which groups have each label
        label_sets = {g: set(per_group_labels[g].flatten().tolist()) for g in group_keys}
        all_labels = set()
        for s in label_sets.values():
            all_labels |= s

        # For each label, compute PoE across groups that have cells with that label
        poe_stats_per_label = {}
        for label in all_labels:
            groups_with_label = [g for g in group_keys if label in label_sets[g]]
            groups_without_label = [g for g in group_keys if label not in label_sets[g]]

            # Build stats dict for _poe_n: groups with label contribute real stats,
            # groups without contribute uninformative prior
            label_stats_for_poe = {}
            for g in groups_with_label:
                mask = (per_group_labels[g] == label).squeeze().reshape(-1)
                label_stats_for_poe[g] = {key: value[mask] for key, value in per_group_stats[g].items()}

            if len(groups_with_label) >= 2:
                # Enough groups for PoE — absent groups contribute near-zero precision so
                # only the global prior inside _product_of_experts (ones_like) acts as prior.
                # Using logvar=30 gives precision ≈ exp(-30) ≈ 0, avoiding the double-prior
                # that would result from logvar=0 (precision=1) + ones_like (precision=1).
                for g in groups_without_label:
                    ref_g = groups_with_label[0]
                    n_cells = label_stats_for_poe[ref_g]["logtheta_loc"].shape[0]
                    latent_dim = label_stats_for_poe[ref_g]["logtheta_loc"].shape[-1]
                    device = label_stats_for_poe[ref_g]["logtheta_loc"].device
                    _large_logvar = torch.full((n_cells, latent_dim), 30.0, device=device)
                    label_stats_for_poe[g] = {
                        "logtheta_loc": torch.zeros(n_cells, latent_dim, device=device),
                        "logtheta_logvar": _large_logvar,
                        "logtheta_scale": torch.exp(0.5 * _large_logvar),
                    }

                poe_result = self._poe_n(label_stats_for_poe)

                # For groups without this label, replace result with empty tensors
                for g in groups_without_label:
                    latent_dim = poe_result[groups_with_label[0]]["logtheta_loc"].shape[-1]
                    device = poe_result[groups_with_label[0]]["logtheta_loc"].device
                    poe_result[g] = {
                        k: torch.empty((0, latent_dim), device=device) for k in stat_keys
                    }

                poe_stats_per_label[label] = poe_result
            else:
                # Only one group has this label — combine with uninformative prior
                g_with = groups_with_label[0]
                real_stats = label_stats_for_poe[g_with]
                n_cells = real_stats["logtheta_loc"].shape[0]
                latent_dim = real_stats["logtheta_loc"].shape[1]
                device = real_stats["logtheta_loc"].device

                # Create a dummy second group for the PoE (uninformative prior)
                dummy_key = -1  # temporary key not in group_keys
                _large_logvar = torch.full((n_cells, latent_dim), 30.0, device=device)
                dummy_stats = {
                    "logtheta_loc": torch.zeros(n_cells, latent_dim, device=device),
                    "logtheta_logvar": _large_logvar,
                    "logtheta_scale": torch.exp(0.5 * _large_logvar),
                }
                poe_result = self._poe_n({g_with: real_stats, dummy_key: dummy_stats})

                # Build final result: only the group with the label gets real stats
                final_result = {}
                for g in group_keys:
                    if g == g_with:
                        final_result[g] = poe_result[g_with]
                    else:
                        final_result[g] = {k: torch.empty((0, latent_dim), device=device) for k in stat_keys}
                poe_stats_per_label[label] = final_result

        # Reassemble: for each group, fill output tensors in original cell order
        # Determine device from first group's stats
        ref_device = per_group_stats[group_keys[0]]["logtheta_loc"].device
        latent_dim = per_group_stats[group_keys[0]]["logtheta_loc"].shape[1]

        concat_poe_stats = {}
        for g in group_keys:
            n_cells = per_group_stats[g]["logtheta_loc"].shape[0]
            group_output = {k: torch.empty(n_cells, latent_dim, dtype=torch.float32, device=ref_device) for k in stat_keys}

            # Vectorized scatter: O(n_labels) boolean-mask ops instead of
            # O(n_cells) .item() calls — eliminates GPU→CPU syncs per cell.
            labels_g = per_group_labels[g]  # 1D, already flattened in _get_inference_input
            for label in all_labels:
                mask = labels_g == label
                if not mask.any():
                    continue
                poe_g = poe_stats_per_label[label][g]
                for k in stat_keys:
                    group_output[k][mask] = poe_g[k]

            concat_poe_stats[g] = group_output

        # Compute qz, log_z, theta for each group
        for g in group_keys:
            concat_poe_stats[g]["logtheta_qz"] = Normal(
                concat_poe_stats[g]["logtheta_loc"], concat_poe_stats[g]["logtheta_scale"].clamp(min=1e-6)
            )
            concat_poe_stats[g]["logtheta_log_z"] = concat_poe_stats[g]["logtheta_qz"].rsample()
            concat_poe_stats[g]["logtheta_theta"] = F.softmax(concat_poe_stats[g]["logtheta_log_z"], -1)

        return concat_poe_stats

    @auto_move_data
    def generative(self, private_stats, shared_stats, poe_stats, library, groups, batch_index, **kwargs):
        """Runs the generative model."""
        if self.is_multimodal:
            return self._generative_multimodal(
                private_stats, shared_stats, poe_stats, library, groups, batch_index, **kwargs
            )

        n_groups = len(private_stats)

        # Concatenate private and PoE latents for each group
        private_poe = {}
        for group in range(n_groups):
            private_log_z = private_stats[group]["log_z"]
            private_theta = private_stats[group]["theta"]
            poe_log_z = poe_stats[group]["logtheta_log_z"]
            poe_theta = poe_stats[group]["logtheta_theta"]
            private_poe[group] = {
                "log_z": torch.cat((private_log_z, poe_log_z), dim=-1),
                "theta": torch.cat((private_theta, poe_theta), dim=-1),
            }

        shared_stats_out = {}

        poe_stats_out = {}
        for (group, stats), batch in zip(private_poe.items(), batch_index):
            key = str(group)
            decoder = self.decoders[group]
            px_scale_private, px_scale_shared, px_rate_private, px_rate_shared, px_mixing, px_scale = decoder(
                self.dispersion,
                stats["log_z"][:, : self.n_dimensions_private],
                stats["log_z"][:, self.n_dimensions_private :],
                library[group],
                batch,
            )
            px_r = torch.exp(self.px_r[group])
            px = NegativeBinomialMixture(mu1=px_rate_private, mu2=px_rate_shared, theta1=px_r, mixture_logits=px_mixing)
            pz = Normal(torch.zeros_like(stats["log_z"]), torch.ones_like(stats["log_z"]))
            poe_stats_out[key] = {
                "px_scale_private": px_scale_private,
                "px_scale_shared": px_scale_shared,
                "px_rate_private": px_rate_private,
                "px_rate_shared": px_rate_shared,
                "px": px,
                "pz": pz,
            }

        outputs = {"private_shared": shared_stats_out, "private_poe": poe_stats_out}
        return outputs

    def _generative_multimodal(self, private_stats, shared_stats, poe_stats, library, groups, batch_index, **kwargs):
        """Multimodal generative model: per-(group, modality) decoding."""
        from spVIPESmulti.module.utils import build_likelihood

        per_modality_private = kwargs.get("per_modality_private", {})
        n_groups = len(poe_stats)

        poe_stats_out = {}
        for group in range(n_groups):
            batch = batch_index[group]
            poe_log_z = poe_stats[group]["logtheta_log_z"]
            poe_theta = poe_stats[group]["logtheta_theta"]

            for modality in self.group_modalities[group]:
                # Get modality-specific private latent
                if (group, modality) in per_modality_private:
                    mod_private = per_modality_private[(group, modality)]
                else:
                    mod_private = private_stats[group]

                private_log_z = mod_private["log_z"]
                private_theta = mod_private["theta"]

                # Concatenate private + shared PoE
                combined_log_z = torch.cat((private_log_z, poe_log_z), dim=-1)

                decoder = self.decoders[(group, modality)]
                mod_library = library.get((group, modality), library.get(group))

                px_scale_private, px_scale_shared, px_rate_private, px_rate_shared, px_mixing, px_scale = decoder(
                    self.dispersion,
                    combined_log_z[:, : self.n_dimensions_private],
                    combined_log_z[:, self.n_dimensions_private :],
                    mod_library,
                    batch,
                )

                px_r_key = f"{group}_{modality}"
                px_r = torch.exp(self.px_r[px_r_key])
                likelihood_type = self.modality_likelihoods.get(modality, "nb")
                log_scale = self.log_scale_gaussian.get(px_r_key) if likelihood_type == "gaussian" else None
                px = build_likelihood(likelihood_type, px_rate_private, px_rate_shared, px_r, px_mixing, px_scale, log_scale=log_scale)
                pz = Normal(torch.zeros_like(combined_log_z), torch.ones_like(combined_log_z))

                key = f"{group}_{modality}"
                poe_stats_out[key] = {
                    "px_scale_private": px_scale_private,
                    "px_scale_shared": px_scale_shared,
                    "px_rate_private": px_rate_private,
                    "px_rate_shared": px_rate_shared,
                    "px": px,
                    "pz": pz,
                }

        outputs = {"private_shared": {}, "private_poe": poe_stats_out}
        return outputs

    @torch.inference_mode()
    def get_loadings(self, dataset, type_latent: str) -> np.ndarray:
        """Extract per-gene weights (for each Z, shape is genes by dim(Z)) in the linear decoder.

        Parameters
        ----------
        dataset : int or tuple
            For single-modal models, an integer group index. For multimodal models,
            a ``(group, modality)`` tuple matching a key in ``self.decoders``.
        type_latent : str
            ``"shared"`` or ``"private"``.
        """
        # This is BW, where B is diag(b) batch norm, W is weight matrix
        if type_latent not in ["shared", "private"]:
            raise ValueError(f"Invalid value for type_latent: {type_latent}. It can only be 'shared' or 'private'")
        if self.use_batch_norm is True:
            w = (
                self.decoders[dataset].factor_regressor_private.fc_layers[0][0].weight
                if type_latent == "private"
                else self.decoders[dataset].factor_regressor_shared.fc_layers[0][0].weight
            )
            bn = (
                self.decoders[dataset].factor_regressor_private.fc_layers[0][1]
                if type_latent == "private"
                else self.decoders[dataset].factor_regressor_shared.fc_layers[0][1]
            )
            sigma = torch.sqrt(bn.running_var + bn.eps)
            gamma = bn.weight
            b = gamma / sigma
            b_identity = torch.diag(b)
            loadings = torch.matmul(b_identity, w)
        else:
            loadings = (
                self.decoders[dataset].factor_regressor_private.fc_layers[0][0].weight
                if type_latent == "private"
                else self.decoders[dataset].factor_regressor_shared.fc_layers[0][0].weight
            )

        loadings = loadings.detach().cpu().numpy()
        if self.n_batch > 1:
            loadings = loadings[:, : -self.n_batch]

        return loadings

    def _compute_disentangle_losses(
        self,
        inference_outputs,
        tensors_by_group,
        n_groups,
        extra_metrics,
        covariate_grl_lambda: float = 1.0,
    ):
        """Compute disentanglement and contrastive losses (sum of all enabled, weighted terms).

        Each component is independently controlled by its weight at construction
        time — set the corresponding ``disentangle_*_weight`` to 0 to ablate that
        component (the network is then never created, no forward/backward cost).

        Returns
        -------
        torch.Tensor or float
            Scalar tensor sum of all enabled, weighted disentanglement terms.
            Returns the literal ``0.0`` when nothing is enabled, so the caller
            can write
            ``total_loss = total_loss + self._compute_disentangle_losses(...)``
            unconditionally.
        """
        # Quick exit when no disentanglement component is enabled
        enabled = (
            self.q_group_shared, self.q_label_shared,
            self.q_group_private, self.q_label_private,
            self.q_batch_shared, self.q_donor_shared, self.q_donor_private,
            self.prototypes,
        )
        if (
            all(x is None for x in enabled)
            and not self.compute_orthogonality_metric
            and self.orthogonality_weight == 0
        ):
            return 0.0

        # Labels are needed only by the label-using components
        needs_labels = (
            self.q_label_shared is not None
            or self.q_label_private is not None
            or self.prototypes is not None
        )
        labels_by_group = None
        if needs_labels:
            # Key by the loop index (position in `tensors_by_group`), not by
            # the categorical code, so this stays correct even if group codes
            # are not contiguous starting at 0 (e.g. after subsetting an adata).
            labels_by_group = {
                gi: grp["labels"].flatten()
                for gi, grp in enumerate(tensors_by_group)
            }

        needs_donor = (
            self.q_donor_shared is not None
            or self.q_donor_private is not None
        )
        donors_by_group = None
        if needs_donor:
            donors_by_group = {
                gi: grp["donor"].flatten()
                for gi, grp in enumerate(tensors_by_group)
            }

        disentangle_total = 0.0

        # Component 1 (q_group_shared): adversarial group erasure on z_shared
        if self.q_group_shared is not None:
            loss_val = sum(
                F.cross_entropy(
                    self.q_group_shared(gradient_reversal(
                        inference_outputs["poe_stats"][g]["logtheta_log_z"]
                    )),
                    torch.full(
                        (inference_outputs["poe_stats"][g]["logtheta_log_z"].size(0),),
                        g, dtype=torch.long,
                        device=inference_outputs["poe_stats"][g]["logtheta_log_z"].device,
                    ),
                )
                for g in range(n_groups)
            )
            disentangle_total = disentangle_total + self.disentangle_group_shared_weight * loss_val
            extra_metrics["disentangle_group_shared_loss"] = loss_val / n_groups

        # Component 2 (q_label_shared): supervised label preservation on z_shared
        if self.q_label_shared is not None:
            loss_val = sum(
                F.cross_entropy(
                    self.q_label_shared(inference_outputs["poe_stats"][g]["logtheta_log_z"]),
                    labels_by_group[g].long(),
                    weight=self.label_class_weights,
                )
                for g in range(n_groups)
            )
            disentangle_total = disentangle_total + self.disentangle_label_shared_weight * loss_val
            extra_metrics["disentangle_label_shared_loss"] = loss_val / n_groups

        # In multimodal mode, private latents are per-(group, modality). Apply
        # the per-private classifiers to every modality's private latent so the
        # disentanglement objective acts on all of them (not just the first
        # modality, which is what `private_stats[g]` holds for backward compat).
        # In single-modality mode, both lists collapse to one tensor per group.
        def _private_zs(g):
            if self.is_multimodal:
                return [
                    inference_outputs["per_modality_private"][(g, mod)]["log_z"]
                    for mod in self.group_modalities[g]
                ]
            return [inference_outputs["private_stats"][g]["log_z"]]

        # Components 3/4 sum over (group, modality) in multimodal mode. The
        # call-site divides the disentangle aggregate by n_groups, so we
        # rescale the multimodal sum back to the per-group scale (multiply by
        # n_groups / n_pairs) — this keeps disentangle_*_weight in per-pair
        # units regardless of n_modalities. In single-modality mode n_pairs
        # equals n_groups and the rescale is a no-op.
        # Component 3 (q_group_private): supervised group preservation on z_private
        if self.q_group_private is not None:
            pair_losses = [
                F.cross_entropy(
                    self.q_group_private(z),
                    torch.full((z.size(0),), g, dtype=torch.long, device=z.device),
                )
                for g in range(n_groups)
                for z in _private_zs(g)
            ]
            n_pairs = len(pair_losses)
            loss_val = sum(pair_losses) * (n_groups / n_pairs) if n_pairs else 0.0
            disentangle_total = disentangle_total + self.disentangle_group_private_weight * loss_val
            extra_metrics["disentangle_group_private_loss"] = (
                loss_val / n_groups if n_pairs else loss_val
            )

        # Component 4 (q_label_private): adversarial label erasure on z_private
        if self.q_label_private is not None:
            pair_losses = [
                F.cross_entropy(
                    self.q_label_private(gradient_reversal(z)),
                    labels_by_group[g].long(),
                    weight=self.label_class_weights,
                )
                for g in range(n_groups)
                for z in _private_zs(g)
            ]
            n_pairs = len(pair_losses)
            loss_val = sum(pair_losses) * (n_groups / n_pairs) if n_pairs else 0.0
            disentangle_total = disentangle_total + self.disentangle_label_private_weight * loss_val
            extra_metrics["disentangle_label_private_loss"] = (
                loss_val / n_groups if n_pairs else loss_val
            )

        # F4-lite: adversarial technical-batch erasure on z_shared.
        if self.q_batch_shared is not None:
            loss_val = sum(
                F.cross_entropy(
                    self.q_batch_shared(
                        gradient_reversal(
                            inference_outputs["poe_stats"][g]["logtheta_log_z"],
                            alpha=covariate_grl_lambda,
                        )
                    ),
                    tensors_by_group[g][REGISTRY_KEYS.BATCH_KEY].flatten().long(),
                )
                for g in range(n_groups)
            )
            disentangle_total = disentangle_total + self.disentangle_batch_shared_weight * loss_val
            extra_metrics["disentangle_batch_shared_loss"] = loss_val / n_groups
            extra_metrics["covariate_grl_lambda"] = torch.tensor(
                float(covariate_grl_lambda),
                device=inference_outputs["poe_stats"][0]["logtheta_log_z"].device,
            )

        # F4-lite: adversarial donor erasure on z_shared.
        if self.q_donor_shared is not None:
            loss_val = sum(
                F.cross_entropy(
                    self.q_donor_shared(
                        gradient_reversal(
                            inference_outputs["poe_stats"][g]["logtheta_log_z"],
                            alpha=covariate_grl_lambda,
                        )
                    ),
                    donors_by_group[g].long(),
                )
                for g in range(n_groups)
            )
            disentangle_total = disentangle_total + self.disentangle_donor_shared_weight * loss_val
            extra_metrics["disentangle_donor_shared_loss"] = loss_val / n_groups
            extra_metrics["covariate_grl_lambda"] = torch.tensor(
                float(covariate_grl_lambda),
                device=inference_outputs["poe_stats"][0]["logtheta_log_z"].device,
            )

        # F4-lite: supervised donor retention on every private latent.
        if self.q_donor_private is not None:
            pair_losses = [
                F.cross_entropy(
                    self.q_donor_private(z),
                    donors_by_group[g].long(),
                )
                for g in range(n_groups)
                for z in _private_zs(g)
            ]
            n_pairs = len(pair_losses)
            loss_val = sum(pair_losses) * (n_groups / n_pairs) if n_pairs else 0.0
            disentangle_total = disentangle_total + self.disentangle_donor_private_weight * loss_val
            extra_metrics["disentangle_donor_private_loss"] = (
                loss_val / n_groups if n_pairs else loss_val
            )

        # Component 5 (contrastive): InfoNCE on z_shared via EMA prototypes
        if self.prototypes is not None:
            with torch.no_grad():
                for g in range(n_groups):
                    z = inference_outputs["poe_stats"][g]["logtheta_log_z"].detach()
                    labels_g = labels_by_group[g].long()
                    for lbl in labels_g.unique():
                        mask = labels_g == lbl
                        if mask.sum() > 0:
                            self.prototypes[g, lbl] = (
                                self.prototype_momentum * self.prototypes[g, lbl]
                                + (1 - self.prototype_momentum) * z[mask].mean(0)
                            )
            if n_groups > 1:
                other_groups = [
                    [gg for gg in range(n_groups) if gg != g] for g in range(n_groups)
                ]
                ct_loss = sum(
                    F.cross_entropy(
                        F.normalize(inference_outputs["poe_stats"][g]["logtheta_log_z"], dim=-1)
                        @ F.normalize(self.prototypes[other_groups[g]].mean(0), dim=-1).T
                        / self.contrastive_temperature,
                        labels_by_group[g].long(),
                    )
                    for g in range(n_groups)
                )
                disentangle_total = disentangle_total + self.contrastive_weight * ct_loss
                extra_metrics["contrastive_loss"] = ct_loss / n_groups

        if self.orthogonality_weight > 0:
            ortho_group_losses: list[torch.Tensor] = []
            for g in range(n_groups):
                # Use posterior means for the F3 training penalty. Penalizing
                # sampled latents made the audit unstable for positive weights.
                z_shared = inference_outputs["poe_stats"][g]["logtheta_loc"]
                strata_ids = _orthogonality_strata_ids(
                    tensors_by_group[g],
                    self.orthogonality_groupby_keys,
                    z_shared.device,
                    z_shared.size(0),
                )
                if strata_ids is None:
                    ortho_group_losses.append(z_shared.sum() * 0.0)
                    continue

                if self.is_multimodal and "per_modality_private" in inference_outputs:
                    z_private_by_modality = {
                        mod: inference_outputs["per_modality_private"][(g, mod)]["logtheta_loc"]
                        for mod in self.group_modalities[g]
                        if (g, mod) in inference_outputs["per_modality_private"]
                    }
                    group_loss = _orthogonality_corr_loss_multimodal(
                        z_shared,
                        z_private_by_modality,
                        strata_ids,
                        min_cells=self.orthogonality_min_cells_per_stratum,
                    )
                else:
                    z_private = inference_outputs["private_stats"][g]["logtheta_loc"]
                    group_loss = _orthogonality_corr_loss(
                        z_shared,
                        z_private,
                        strata_ids,
                        min_cells=self.orthogonality_min_cells_per_stratum,
                    )
                ortho_group_losses.append(group_loss)

            loss_val = sum(ortho_group_losses) if ortho_group_losses else (
                inference_outputs["poe_stats"][0]["logtheta_log_z"].sum() * 0.0
            )
            disentangle_total = disentangle_total + self.orthogonality_weight * loss_val
            extra_metrics["orthogonality_loss"] = loss_val.detach() / n_groups

        if self.compute_orthogonality_metric:
            ortho_means: list[float] = []
            ortho_worsts: list[float] = []
            excluded_total = 0

            for g in range(n_groups):
                z_shared = inference_outputs["poe_stats"][g]["logtheta_log_z"].detach()
                strata_ids = _orthogonality_strata_ids(
                    tensors_by_group[g],
                    self.orthogonality_groupby_keys,
                    z_shared.device,
                    z_shared.size(0),
                )
                if strata_ids is None:
                    continue

                if self.is_multimodal and "per_modality_private" in inference_outputs:
                    z_private_by_modality = {
                        mod: inference_outputs["per_modality_private"][(g, mod)]["log_z"].detach()
                        for mod in self.group_modalities[g]
                        if (g, mod) in inference_outputs["per_modality_private"]
                    }
                    mean_val, worst_val, excluded = _within_stratum_corr_norm_multimodal(
                        z_shared,
                        z_private_by_modality,
                        strata_ids,
                        min_cells=self.orthogonality_min_cells_per_stratum,
                    )
                else:
                    z_private = inference_outputs["private_stats"][g]["log_z"].detach()
                    mean_val, worst_val, excluded = _within_stratum_corr_norm(
                        z_shared,
                        z_private,
                        strata_ids,
                        min_cells=self.orthogonality_min_cells_per_stratum,
                    )

                ortho_means.append(mean_val)
                ortho_worsts.append(worst_val)
                excluded_total += excluded

            if ortho_means:
                metric_device = inference_outputs["poe_stats"][0]["logtheta_log_z"].device
                # Canonical F1 instrumentation names.
                extra_metrics["orthogonality_within_stratum"] = torch.tensor(
                    np.mean(ortho_means), device=metric_device
                )
                extra_metrics["orthogonality_worst_stratum"] = torch.tensor(
                    np.max(ortho_worsts), device=metric_device
                )
                extra_metrics["orthogonality_excluded_strata"] = torch.tensor(float(excluded_total), device=metric_device)

        return disentangle_total

    def _validate_likelihood_observations(
        self,
        x_obs: torch.Tensor,
        likelihood_type: str,
        context: str,
        transformed_for_nb: bool = False,
    ) -> None:
        """Validate observed targets before likelihood log-prob evaluation.

        The cheap isfinite / non-negative scans are gated behind
        ``validate_observations`` (default ``False``) to avoid two full tensor
        scans per group per training step.  The ``strict_likelihood_support``
        integer-roundness check always runs when that flag is ``True`` because
        it is already an explicit opt-in by the caller.
        """
        if self.validate_observations:
            if not torch.isfinite(x_obs).all():
                raise ValueError(
                    f"Invalid observations in {context}: expected finite values for "
                    f"likelihood '{likelihood_type}'."
                )

            if likelihood_type == "nb":
                if (x_obs < 0).any():
                    raise ValueError(
                        f"Invalid observations in {context}: NegativeBinomial likelihood "
                        "requires non-negative targets."
                    )

        if likelihood_type == "nb" and self.strict_likelihood_support and not transformed_for_nb:
            nearest_int = torch.round(x_obs)
            if not torch.allclose(x_obs, nearest_int, atol=1e-6, rtol=0.0):
                raise ValueError(
                    f"Invalid observations in {context}: strict support validation "
                    "requires integer-like count targets for NB likelihood. "
                    "Disable strict_likelihood_support or provide integer counts."
                )

    def loss(
        self,
        tensors_by_group,
        inference_outputs,
        generative_outputs,
        kl_weight: float = 1.0,
    ):
        """Loss function with optional NF prior KL and cycle consistency."""
        if self.is_multimodal:
            return self._loss_multimodal(tensors_by_group, inference_outputs, generative_outputs, kl_weight)

        per_group = self._split_tensors_by_group(tensors_by_group)
        x = {i: g[REGISTRY_KEYS.X_KEY] for i, g in enumerate(per_group)}
        x = {i: xs[:, self.groups_var_indices[i]] for i, xs in x.items()}

        n_groups = len(x)
        extra_metrics = {}
        reconst_losses = {}
        kl_local = {}
        total_loss = None

        for g in range(n_groups):
            x_obs = x[g]
            self._validate_likelihood_observations(
                x_obs,
                likelihood_type="nb",
                context=f"group={g}",
                transformed_for_nb=False,
            )

            x_target = x_obs
            if self.log_variational_generative:
                x_target = torch.log(1 + x_obs)
                self._validate_likelihood_observations(
                    x_target,
                    likelihood_type="nb",
                    context=f"group={g}",
                    transformed_for_nb=True,
                )

            # Reconstruction loss
            recon_loss = -generative_outputs["private_poe"][str(g)]["px"].log_prob(x_target).sum(-1)

            # KL divergence — private latent
            qz_private = inference_outputs["private_stats"][g]["qz"]
            z_private = inference_outputs["private_stats"][g]["log_z"]
            if self.use_nf_prior and self.nf_target in ("private", "both"):
                kl_private = self._nf_kl(qz_private, z_private, "private")
            else:
                kl_private = kl(
                    qz_private,
                    Normal(torch.zeros_like(z_private), torch.ones_like(z_private)),
                ).sum(dim=1)

            # KL divergence — shared (PoE) latent
            qz_poe = inference_outputs["poe_stats"][g]["logtheta_qz"]
            z_poe = inference_outputs["poe_stats"][g]["logtheta_log_z"]
            if self.use_nf_prior and self.nf_target in ("shared", "both"):
                kl_poe = self._nf_kl(qz_poe, z_poe, "shared")
            else:
                kl_poe = kl(
                    qz_poe,
                    Normal(torch.zeros_like(z_poe), torch.ones_like(z_poe)),
                ).sum(dim=1)

            extra_metrics[f"kl_divergence_private_group_{g}"] = kl_private.mean()
            extra_metrics[f"kl_divergence_poe_group_{g}"] = kl_poe.mean()
            reconst_losses[f"reconst_loss_group_{g}_poe"] = recon_loss.mean()
            kl_local[f"kl_divergence_group_{g}_private"] = kl_private.mean()
            kl_local[f"kl_divergence_group_{g}_poe"] = kl_poe.mean()

            group_loss = recon_loss + kl_weight * kl_private + kl_weight * kl_poe
            # Aggregate each group to a scalar so groups with unequal batch
            # lengths can be combined safely.
            group_loss = group_loss.mean()
            w = self.group_loss_weights[g] if self.group_loss_weights is not None else 1.0 / n_groups
            total_loss = group_loss * w if total_loss is None else total_loss + group_loss * w

        disentangle_scale = kl_weight if self.disentangle_warmup else 1.0
        covariate_grl_lambda = self._covariate_grl_lambda(kl_weight)
        total_loss = total_loss + (disentangle_scale / n_groups) * self._compute_disentangle_losses(
            inference_outputs, per_group, n_groups, extra_metrics, covariate_grl_lambda
        )

        if self.use_jeffreys_integ:
            jeffreys_loss = self._compute_jeffreys_integ_loss(inference_outputs, n_groups, extra_metrics)
            total_loss = total_loss + self.jeffreys_integ_weight * jeffreys_loss

        loss = torch.mean(total_loss)

        output = LossOutput(
            loss=loss,
            reconstruction_loss=reconst_losses,
            kl_local=kl_local,
            extra_metrics=extra_metrics,
            n_obs_minibatch=sum(v.shape[0] for v in x.values()),
        )

        return output

    def _loss_multimodal(self, tensors_by_group, inference_outputs, generative_outputs, kl_weight):
        """Multimodal loss: sum over groups and modalities."""
        per_group = self._split_tensors_by_group(tensors_by_group)
        x = {i: g[REGISTRY_KEYS.X_KEY] for i, g in enumerate(per_group)}

        n_groups = len(x)
        extra_metrics = {}
        reconst_losses = {}
        kl_local = {}
        total_loss = None

        per_modality_private = inference_outputs.get("per_modality_private", {})

        for g in range(n_groups):
            x_group = x[g]
            group_loss = None

            # Per-modality reconstruction losses
            for modality in self.group_modalities[g]:
                key = f"{g}_{modality}"
                gen_stats = generative_outputs["private_poe"][key]

                # Get modality-specific target data
                mod_var_indices = self.groups_modality_var_indices[g][modality]
                x_mod = x_group[:, mod_var_indices]

                likelihood_type = self.modality_likelihoods.get(modality, "nb")
                self._validate_likelihood_observations(
                    x_mod,
                    likelihood_type=likelihood_type,
                    context=f"group={g}, modality={modality}",
                    transformed_for_nb=False,
                )
                if likelihood_type == "nb" and self.log_variational_generative:
                    x_mod = torch.log(1 + x_mod)
                    self._validate_likelihood_observations(
                        x_mod,
                        likelihood_type=likelihood_type,
                        context=f"group={g}, modality={modality}",
                        transformed_for_nb=True,
                    )

                recon_loss = -gen_stats["px"].log_prob(x_mod).sum(-1)
                reconst_losses[f"reconst_loss_group_{g}_{modality}"] = recon_loss.mean()

                # Per-modality private KL (if available)
                if (g, modality) in per_modality_private:
                    qz_mod_private = per_modality_private[(g, modality)]["qz"]
                    z_mod_private = per_modality_private[(g, modality)]["log_z"]
                    if self.use_nf_prior and self.nf_target in ("private", "both"):
                        kl_mod_private = self._nf_kl(qz_mod_private, z_mod_private, "private")
                    else:
                        kl_mod_private = kl(
                            qz_mod_private,
                            Normal(
                                torch.zeros_like(z_mod_private),
                                torch.ones_like(z_mod_private),
                            ),
                        ).sum(dim=1)
                    kl_local[f"kl_divergence_group_{g}_{modality}_private"] = kl_mod_private.mean()
                    extra_metrics[f"kl_divergence_private_group_{g}_{modality}"] = kl_mod_private.mean()
                else:
                    kl_mod_private = torch.zeros(x_mod.shape[0], device=x_mod.device)

                mod_weight = self.modality_loss_weights.get(modality, 1.0)
                n_modalities = len(self.group_modalities[g])
                mod_loss = mod_weight * recon_loss + kl_weight * (kl_mod_private / n_modalities)
                mod_loss = mod_loss.mean()
                group_loss = mod_loss if group_loss is None else group_loss + mod_loss

            # Per-group PoE KL (shared across modalities)
            qz_poe = inference_outputs["poe_stats"][g]["logtheta_qz"]
            z_poe = inference_outputs["poe_stats"][g]["logtheta_log_z"]
            if self.use_nf_prior and self.nf_target in ("shared", "both"):
                kl_poe = self._nf_kl(qz_poe, z_poe, "shared")
            else:
                kl_poe = kl(
                    qz_poe,
                    Normal(
                        torch.zeros_like(z_poe),
                        torch.ones_like(z_poe),
                    ),
                ).sum(dim=1)

            extra_metrics[f"kl_divergence_poe_group_{g}"] = kl_poe.mean()
            kl_local[f"kl_divergence_group_{g}_poe"] = kl_poe.mean()
            group_loss = group_loss + kl_weight * kl_poe.mean()

            w = self.group_loss_weights[g] if self.group_loss_weights is not None else 1.0 / n_groups
            total_loss = group_loss * w if total_loss is None else total_loss + group_loss * w

        # P8: disentanglement objective on multimodal mode. The helper early-
        # exits when no component is enabled, so the cost is one tuple
        # comparison when disentangle_preset='off'. Helper sums across groups
        # internally, so divide by n_groups to keep disentangle_*_weight in
        # per-group units (same relative scale as before the sum→mean change).
        disentangle_scale = kl_weight if self.disentangle_warmup else 1.0
        covariate_grl_lambda = self._covariate_grl_lambda(kl_weight)
        total_loss = total_loss + (disentangle_scale / n_groups) * self._compute_disentangle_losses(
            inference_outputs, per_group, n_groups, extra_metrics, covariate_grl_lambda
        )

        if self.use_jeffreys_integ:
            jeffreys_loss = self._compute_jeffreys_integ_loss(inference_outputs, n_groups, extra_metrics)
            total_loss = total_loss + self.jeffreys_integ_weight * jeffreys_loss

        loss = torch.mean(total_loss)

        return LossOutput(
            loss=loss,
            reconstruction_loss=reconst_losses,
            kl_local=kl_local,
            extra_metrics=extra_metrics,
            n_obs_minibatch=sum(v.shape[0] for v in x.values()),
        )
